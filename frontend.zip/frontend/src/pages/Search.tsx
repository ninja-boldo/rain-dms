import React, { useState, useMemo } from "react";
import { useApp } from "../lib/AppContext";
import { useSearch } from "../hooks/useApi";
import { SearchHit } from "../types";
import OcrOverlay from "../components/documents/OcrOverlay";
import styles from "./Search.module.css";

const SearchIcon = () => (
  <svg
    width="18"
    height="18"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="11" cy="11" r="8" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);

const Spinner = () => (
  <div
    style={{
      width: 18,
      height: 18,
      border: "2px solid var(--border-accent)",
      borderTopColor: "var(--accent)",
      borderRadius: "50%",
      animation: "spin 0.7s linear infinite",
    }}
  />
);

function getFilename(filepath?: string): string {
  if (!filepath) return "Unknown Document";
  const parts = filepath.split(/[\\\/]/);
  const name = parts[parts.length - 1];
  return name
    .replace(/-\[object Object\]-[\d-T.Z]+\.(pdf|png|jpg|jpeg)$/i, ".$1")
    .replace(/\.(pdf|png|jpg|jpeg)$/i, "");
}

function getMatchCount(hit: SearchHit, query: string): number {
  if (!query) return 0;
  const q = query.toLowerCase();
  return (
    hit.ocr?.lines
      ?.flatMap((l) => l.boxes)
      .filter((b) => b.text.toLowerCase().includes(q)).length ?? 0
  );
}

// Group hits by filepath → array of hits (pages) per document
function groupByFile(hits: SearchHit[]): Map<string, SearchHit[]> {
  const map = new Map<string, SearchHit[]>();
  for (const hit of hits) {
    const key = hit.filepath ?? `__unknown_${hit.id}`;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(hit);
  }
  return map;
}

interface GroupedResultProps {
  filepath: string;
  pages: SearchHit[];
  query: string;
  showAllPages: boolean;
}

function GroupedResult({
  filepath,
  pages,
  query,
  showAllPages,
}: GroupedResultProps) {
  const [pageIdx, setPageIdx] = useState(0);
  const [overlayOpen, setOverlayOpen] = useState(false);
  const [imgError, setImgError] = useState(false);

  const currentHit = pages[pageIdx];
  const filename = getFilename(filepath);
  const totalMatches = pages.reduce(
    (acc, p) => acc + getMatchCount(p, query),
    0,
  );
  const currentMatches = getMatchCount(currentHit, query);

  // Pages that have matches
  const matchingPageIdxs = useMemo(() => {
    return pages
      .map((p, i) => ({ i, count: getMatchCount(p, query) }))
      .filter((x) => x.count > 0);
  }, [pages, query]);

  // Navigate only through matching pages unless showAllPages
  const visiblePages = showAllPages
    ? pages.map((_, i) => i)
    : matchingPageIdxs.map((x) => x.i);

  const posInVisible = visiblePages.indexOf(pageIdx);
  const canPrev = posInVisible > 0;
  const canNext = posInVisible < visiblePages.length - 1;

  const goPrev = () => {
    if (canPrev) setPageIdx(visiblePages[posInVisible - 1]);
  };
  const goNext = () => {
    if (canNext) setPageIdx(visiblePages[posInVisible + 1]);
  };

  return (
    <>
      <div
        className={styles.groupCard}
        onClick={() => setOverlayOpen(true)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && setOverlayOpen(true)}
      >
        <div className={styles.groupThumb}>
          {currentHit.banner_img && !imgError ? (
            <img
              src={currentHit.banner_img}
              alt={filename}
              onError={() => setImgError(true)}
              className={styles.groupThumbImg}
            />
          ) : (
            <div className={styles.groupThumbFallback}>
              <span>PDF</span>
            </div>
          )}
          <div className={styles.groupThumbOverlay}>
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" />
            </svg>
          </div>
        </div>

        <div className={styles.groupContent}>
          <div className={styles.groupHeader}>
            <p className={styles.groupFilename}>{filename}</p>
            <div className={styles.groupBadges}>
              {totalMatches > 0 && (
                <span className={styles.matchBadge}>
                  {totalMatches} Treffer
                </span>
              )}
              {pages.length > 1 && (
                <span className={styles.pageBadge}>{pages.length} Seiten</span>
              )}
            </div>
          </div>

          {/* Per-page match summary */}
          {pages.length > 1 && (
            <div
              className={styles.pageNav}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className={styles.pageNavBtn}
                disabled={!canPrev}
                onClick={goPrev}
              >
                ‹
              </button>
              <span className={styles.pageNavLabel}>
                Seite {pageIdx + 1} von {pages.length}
                {currentMatches > 0 && (
                  <span className={styles.pageMatchBadge}>
                    {" "}
                    · {currentMatches}✓
                  </span>
                )}
              </span>
              <button
                className={styles.pageNavBtn}
                disabled={!canNext}
                onClick={goNext}
              >
                ›
              </button>
            </div>
          )}

          <p className={styles.groupSnippet}>
            {currentHit.ocr?.lines
              ?.flatMap((l) => l.boxes.map((b) => b.text))
              .join(" ")
              .slice(0, 160)}
            ...
          </p>

          <div className={styles.groupFooter}>
            <span className={styles.groupDate}>
              {new Date(currentHit.created_at).toLocaleDateString("de-DE", {
                day: "2-digit",
                month: "short",
                year: "numeric",
              })}
            </span>
            <span className={styles.viewHint}>OCR ansehen →</span>
          </div>
        </div>
      </div>

      {overlayOpen && (
        <OcrOverlay
          hit={currentHit}
          query={query}
          onClose={() => setOverlayOpen(false)}
        />
      )}
    </>
  );
}

// Tag/token chip in searchbar
interface SearchToken {
  type: "text" | "tag" | "boolean";
  value: string;
}

function parseTokens(raw: string): SearchToken[] {
  const tokens: SearchToken[] = [];
  const parts = raw.match(/tag:[^\s]+|AND|OR|NOT|[^\s]+/g) ?? [];
  for (const part of parts) {
    if (part.startsWith("tag:"))
      tokens.push({ type: "tag", value: part.slice(4) });
    else if (["AND", "OR", "NOT"].includes(part))
      tokens.push({ type: "boolean", value: part });
    else tokens.push({ type: "text", value: part });
  }
  return tokens;
}

export default function Search() {
  const { t } = useApp();
  const [query, setQuery] = useState("");
  const [showAllPages, setShowAllPages] = useState(false);
  const { data, loading, error } = useSearch(query);

  const grouped = useMemo(() => {
    if (!data?.hits) return [];
    const map = groupByFile(data.hits);
    return Array.from(map.entries());
  }, [data]);

  const tokens = parseTokens(query);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1 className={styles.title}>{t.search.title}</h1>
      </header>

      {/* Search bar */}
      <div className={styles.searchBar}>
        <span className={styles.searchIcon}>
          <SearchIcon />
        </span>
        <input
          type="text"
          className={styles.input}
          placeholder={`${t.search.placeholder} · tag:Rechnung · AND OR NOT`}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
          spellCheck={false}
        />
        {loading && (
          <span className={styles.spinnerWrap}>
            <Spinner />
          </span>
        )}
        {query && !loading && (
          <button className={styles.clearBtn} onClick={() => setQuery("")}>
            ✕
          </button>
        )}
      </div>

      {/* Token preview */}
      {query && tokens.length > 1 && (
        <div className={styles.tokenRow}>
          {tokens.map((tok, i) => (
            <span
              key={i}
              className={`${styles.token} ${styles[`token_${tok.type}`]}`}
            >
              {tok.value}
            </span>
          ))}
        </div>
      )}

      {error && (
        <div className={styles.error}>
          {t.common.error}: {error}
        </div>
      )}

      {data && (
        <div className={styles.meta}>
          <span className={styles.hitCount}>
            {grouped.length} Dokumente · {data.estimatedTotalHits}{" "}
            {t.search.hits}
          </span>
          <span className={styles.timing}>
            {data.processingTimeMs}
            {t.search.ms}
          </span>

          {/* Show all pages toggle */}
          {data.hits.length > 0 && (
            <label
              className={styles.toggle}
              onClick={(e) => e.stopPropagation()}
            >
              <input
                type="checkbox"
                checked={showAllPages}
                onChange={(e) => setShowAllPages(e.target.checked)}
                className={styles.toggleInput}
              />
              <span className={styles.toggleTrack}>
                <span className={styles.toggleThumb} />
              </span>
              <span className={styles.toggleLabel}>Alle Seiten</span>
            </label>
          )}
        </div>
      )}

      {data && grouped.length === 0 && query && !loading && (
        <div className={styles.empty}>
          <p>
            {t.search.noResults} <strong>„{query}"</strong>
          </p>
        </div>
      )}

      {grouped.length > 0 && (
        <div className={styles.results}>
          {grouped.map(([filepath, pages]) => (
            <GroupedResult
              key={filepath}
              filepath={filepath}
              pages={pages}
              query={query}
              showAllPages={showAllPages}
            />
          ))}
        </div>
      )}

      {!query && (
        <div className={styles.emptyState}>
          <div className={styles.emptyIcon}>
            <SearchIcon />
          </div>
          <p>{t.search.placeholder}</p>
          <p className={styles.emptyHint}>
            Tipp: <code>tag:Rechnung</code> · <code>Müller AND Vertrag</code>
          </p>
        </div>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
