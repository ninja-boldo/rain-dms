import React, { useEffect, useRef, useState } from "react";
import { useApp } from "../lib/AppContext";
import styles from "./Dashboard.module.css";

/* ─── Types ─────────────────────────────────────────────────── */
interface DashStats {
  total_documents: number;
  added_last_1h: number;
  added_last_24h: number;
  added_last_7d: number;
  docs_per_minute: number;
  ocr_queue_length: number;
  merge_queue_length: number;
  ocr_workers_active: number;
  merge_workers_active: number;
  ocr_workers_total: number;
  merge_workers_total: number;
  currently_processing: number;
}

/* ─── Mini components ────────────────────────────────────────── */
function StatCard({
  label,
  value,
  sub,
  accent,
}: {
  label: string;
  value: string | number;
  sub?: string;
  accent?: boolean;
}) {
  return (
    <div
      className={`${styles.statCard} ${accent ? styles.statCardAccent : ""}`}
    >
      <p className={styles.statLabel}>{label}</p>
      <p className={styles.statValue}>{value}</p>
      {sub && <p className={styles.statSub}>{sub}</p>}
    </div>
  );
}

function WorkerDots({ active, total }: { active: number; total: number }) {
  return (
    <div className={styles.workerDots}>
      {Array.from({ length: Math.max(total, active) }).map((_, i) => (
        <span
          key={i}
          className={`${styles.workerDot} ${i < active ? styles.workerDotActive : ""}`}
        />
      ))}
    </div>
  );
}

/* Animated queue: items flow left → right, disappear */
function QueueViz({
  length,
  label,
  color,
}: {
  length: number;
  label: string;
  color: string;
}) {
  const MAX_SHOWN = 12;
  const shown = Math.min(length, MAX_SHOWN);
  const overflow = length > MAX_SHOWN ? length - MAX_SHOWN : 0;

  return (
    <div className={styles.queueWrap}>
      <div className={styles.queueHeader}>
        <span className={styles.queueLabel}>{label}</span>
        <span className={styles.queueCount} style={{ color }}>
          {length} items
        </span>
      </div>
      <div className={styles.queueTrack}>
        {/* Inlet arrow */}
        <div className={styles.queueArrow} style={{ color }}>
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          >
            <line x1="5" y1="12" x2="19" y2="12" />
            <polyline points="12 5 19 12 12 19" />
          </svg>
        </div>

        <div className={styles.queueItems}>
          {Array.from({ length: shown }).map((_, i) => (
            <div
              key={i}
              className={styles.queueItem}
              style={{
                background: color,
                animationDelay: `${i * 0.18}s`,
                opacity: 0.7 + (i / shown) * 0.3,
              }}
            />
          ))}
          {overflow > 0 && (
            <div className={styles.queueOverflow} style={{ color }}>
              +{overflow}
            </div>
          )}
        </div>

        {/* Outlet: worker spinner */}
        <div className={styles.queueWorker} style={{ borderTopColor: color }} />
      </div>

      {length === 0 && <p className={styles.queueEmpty}>Warteschlange leer</p>}
    </div>
  );
}

/* Throughput sparkline */
function Sparkline({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data, 0.01);
  const W = 120,
    H = 36;
  const pts = data
    .map((v, i) => `${(i / (data.length - 1)) * W},${H - (v / max) * H}`)
    .join(" ");
  return (
    <svg width={W} height={H} className={styles.sparkline}>
      <polyline
        points={pts}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {data.map((v, i) => (
        <circle
          key={i}
          cx={(i / (data.length - 1)) * W}
          cy={H - (v / max) * H}
          r="2"
          fill={color}
          opacity="0.6"
        />
      ))}
    </svg>
  );
}

/* ─── Main page ──────────────────────────────────────────────── */
export default function Dashboard() {
  const { settings } = useApp();
  const [stats, setStats] = useState<DashStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [throughputHistory, setThroughputHistory] = useState<number[]>(
    Array(20).fill(0),
  );
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchStats = async () => {
    try {
      const res = await fetch(`${settings.serverUrl}/stats`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: DashStats = await res.json();
      setStats(data);
      setError(null);
      setThroughputHistory((prev) => [...prev.slice(1), data.docs_per_minute]);
    } catch (e: any) {
      setError(e.message);
    }
  };

  useEffect(() => {
    fetchStats();
    intervalRef.current = setInterval(fetchStats, 3000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [settings.serverUrl]);

  const accentColor = "var(--accent)";
  const blueColor = "#58a6ff";

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div>
          <h1 className={styles.title}>Dashboard</h1>
          <p className={styles.subtitle}>Live · alle 3 Sekunden</p>
        </div>
        {error && (
          <div className={styles.errorBadge}>
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            >
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            {error}
          </div>
        )}
        <div className={styles.pulse}>
          <span className={styles.pulseDot} />
          LIVE
        </div>
      </header>

      {/* Stat grid */}
      <div className={styles.statsGrid}>
        <StatCard
          label="Gesamt-Dokumente"
          value={stats?.total_documents?.toLocaleString("de-DE") ?? "—"}
          accent
        />
        <StatCard
          label="Letzte Stunde"
          value={stats?.added_last_1h ?? "—"}
          sub="neue Dokumente"
        />
        <StatCard
          label="Letzte 24h"
          value={stats?.added_last_24h ?? "—"}
          sub="neue Dokumente"
        />
        <StatCard
          label="Letzte 7 Tage"
          value={stats?.added_last_7d ?? "—"}
          sub="neue Dokumente"
        />
        <StatCard
          label="Durchsatz"
          value={stats ? `${stats.docs_per_minute.toFixed(1)}/min` : "—"}
          sub="Dokumente/Minute"
        />
        <StatCard
          label="In Bearbeitung"
          value={stats?.currently_processing ?? "—"}
          sub="aktive Jobs"
        />
      </div>

      {/* Throughput chart */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <p className={styles.sectionTitle}>Durchsatz-Verlauf</p>
          <Sparkline data={throughputHistory} color="var(--accent)" />
        </div>
      </div>

      {/* Workers */}
      <div className={styles.section}>
        <p className={styles.sectionTitle}>Worker-Status</p>
        <div className={styles.workersRow}>
          <div className={styles.workerBlock}>
            <div className={styles.workerBlockHeader}>
              <span className={styles.workerName}>OCR Workers</span>
              <span
                className={styles.workerActive}
                style={{ color: "var(--accent)" }}
              >
                {stats?.ocr_workers_active ?? "—"} /{" "}
                {stats?.ocr_workers_total ?? "—"} aktiv
              </span>
            </div>
            <WorkerDots
              active={stats?.ocr_workers_active ?? 0}
              total={stats?.ocr_workers_total ?? 4}
            />
          </div>
          <div className={styles.workerBlock}>
            <div className={styles.workerBlockHeader}>
              <span className={styles.workerName}>Merge Worker</span>
              <span
                className={styles.workerActive}
                style={{ color: blueColor }}
              >
                {stats?.merge_workers_active ?? "—"} /{" "}
                {stats?.merge_workers_total ?? "—"} aktiv
              </span>
            </div>
            <WorkerDots
              active={stats?.merge_workers_active ?? 0}
              total={stats?.merge_workers_total ?? 2}
            />
          </div>
        </div>
      </div>

      {/* Queues */}
      <div className={styles.section}>
        <p className={styles.sectionTitle}>Warteschlangen</p>
        <div className={styles.queuesRow}>
          <QueueViz
            length={stats?.ocr_queue_length ?? 0}
            label="OCR-Queue → Worker"
            color="var(--accent)"
          />
          <div className={styles.queueConnector}>
            <svg width="32" height="24" viewBox="0 0 32 24" fill="none">
              <line
                x1="0"
                y1="12"
                x2="28"
                y2="12"
                stroke="var(--border-accent)"
                strokeWidth="1.5"
                strokeDasharray="4 3"
              />
              <polyline
                points="20 5 28 12 20 19"
                stroke="var(--border-accent)"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </div>
          <QueueViz
            length={stats?.merge_queue_length ?? 0}
            label="Merge-Queue → DB"
            color={blueColor}
          />
        </div>
      </div>

      {/* API contract note */}
      <details className={styles.apiNote}>
        <summary className={styles.apiNoteSummary}>
          Benötigte Backend-Endpunkte
        </summary>
        <div className={styles.apiNoteBody}>
          <p>
            Füge <code>GET /stats</code> zu deinem Hono-Backend hinzu, das
            folgendes JSON zurückgibt:
          </p>
          <pre className={styles.apiCode}>{`{
  "total_documents": 1234,
  "added_last_1h": 5,
  "added_last_24h": 42,
  "added_last_7d": 210,
  "docs_per_minute": 0.7,
  "ocr_queue_length": 3,
  "merge_queue_length": 1,
  "ocr_workers_active": 2,
  "ocr_workers_total": 4,
  "merge_workers_active": 1,
  "merge_workers_total": 1,
  "currently_processing": 2
}`}</pre>
          <p>
            Die Werte kannst du aus deiner PG-DB holen (<code>COUNT(*)</code>,
            Timestamps), und die Worker-/Queue-Länge aus deinem internen State
            oder BullMQ/Redis.
          </p>
          <p>
            Außerdem: <code>GET /main_page</code> sollte{" "}
            <code>X-Total-Count: &lt;n&gt;</code> als Response-Header senden,
            damit die Archiv-Seite die Gesamtanzahl zeigt.
          </p>
        </div>
      </details>
    </div>
  );
}
