import React, { useEffect, useRef, useState, useCallback } from "react";
import { SearchHit } from "../../types";
import styles from "./OcrOverlay.module.css";

interface Props {
  hit: SearchHit;
  query?: string;
  onClose: () => void;
}

function getFilename(filepath?: string): string {
  if (!filepath) return "Unknown Document";
  const parts = filepath.split(/[\\\/]/);
  const name = parts[parts.length - 1];
  return name
    .replace(/-\[object Object\]-[\d-T.Z]+\.(pdf|png|jpg|jpeg)$/i, ".$1")
    .replace(/\.(pdf|png|jpg|jpeg)$/i, "");
}

export default function OcrOverlay({ hit, query, onClose }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [hoveredBox, setHoveredBox] = useState<number | null>(null);
  const [naturalSize, setNaturalSize] = useState({ w: 0, h: 0 });
  const [canvasSize, setCanvasSize] = useState({ w: 0, h: 0 });
  const [matchOnly, setMatchOnly] = useState(!!query); // default: show only match boxes when query exists
  const [locating, setLocating] = useState(false);

  const filename = getFilename(hit?.filepath);

  const allBoxes =
    hit?.ocr?.lines?.flatMap((line, li) =>
      (line.boxes || []).map((box, bi) => ({
        ...box,
        lineIdx: li,
        boxIdx: bi,
      })),
    ) ?? [];

  const matchBoxes = query
    ? allBoxes.filter((b) => b.text.toLowerCase().includes(query.toLowerCase()))
    : allBoxes;

  const visibleBoxes = matchOnly && query ? matchBoxes : allBoxes;

  const drawBoxes = useCallback(
    (highlightIdx: number | null) => {
      const canvas = canvasRef.current;
      if (!canvas || !imgLoaded || naturalSize.w === 0) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const scaleX = canvasSize.w / naturalSize.w;
      const scaleY = canvasSize.h / naturalSize.h;

      ctx.clearRect(0, 0, canvasSize.w, canvasSize.h);

      visibleBoxes.forEach((box, idx) => {
        const { upLeftPoint: ul, downRightPoint: dr } = box.boundingBox;
        const x = ul.x * scaleX;
        const y = ul.y * scaleY;
        const w = (dr.x - ul.x) * scaleX;
        const h = (dr.y - ul.y) * scaleY;

        const isMatch =
          !!query && box.text.toLowerCase().includes(query.toLowerCase());
        const isHovered = idx === highlightIdx;
        const alpha = isHovered ? 0.6 : isMatch ? 0.45 : 0.18;

        if (isMatch) {
          ctx.fillStyle = `rgba(88, 166, 255, ${alpha})`;
        } else {
          ctx.fillStyle = `rgba(200, 168, 75, ${alpha})`;
        }
        ctx.fillRect(x, y, w, h);

        if (isMatch) {
          ctx.strokeStyle = isHovered
            ? "rgba(88, 166, 255, 1)"
            : "rgba(88, 166, 255, 0.8)";
        } else {
          ctx.strokeStyle = isHovered
            ? "rgba(200, 168, 75, 0.95)"
            : "rgba(200, 168, 75, 0.5)";
        }
        ctx.lineWidth = isHovered || isMatch ? 2 : 1;
        ctx.strokeRect(x, y, w, h);

        const conf = box.confidence;
        if (conf < 0.8) {
          ctx.fillStyle = `rgba(196, 90, 74, 0.7)`;
          ctx.fillRect(x, y, 4, 4);
        }
      });

      // Tooltip for hovered
      if (highlightIdx !== null) {
        const box = visibleBoxes[highlightIdx];
        if (box) {
          const { upLeftPoint: ul, downRightPoint: dr } = box.boundingBox;
          const x = ul.x * scaleX;
          const y = ul.y * scaleY;
          const w = (dr.x - ul.x) * scaleX;
          const text = box.text;
          const conf = (box.confidence * 100).toFixed(0) + "%";
          const label = `${text}  ·  ${conf}`;
          ctx.font = "500 12px 'IBM Plex Mono', monospace";
          const tw = ctx.measureText(label).width;
          const px = 8,
            py = 5;
          const bw = tw + px * 2,
            bh = 22;
          let tx = x;
          let ty = y - bh - 4;
          if (ty < 0) ty = y + (dr.y - ul.y) * scaleY + 4;
          if (tx + bw > canvasSize.w) tx = canvasSize.w - bw - 4;
          ctx.fillStyle = "rgba(14, 13, 11, 0.92)";
          ctx.beginPath();
          ctx.roundRect(tx, ty, bw, bh, 4);
          ctx.fill();
          ctx.fillStyle = "#c8a84b";
          ctx.fillText(label, tx + px, ty + 15);
        }
      }
    },
    [visibleBoxes, imgLoaded, naturalSize, canvasSize, query],
  );

  useEffect(() => {
    drawBoxes(hoveredBox);
  }, [hoveredBox, drawBoxes]);

  const syncCanvasSize = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img) return;
    const rect = img.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;
    setCanvasSize({ w: rect.width, h: rect.height });
  }, []);

  useEffect(() => {
    const ro = new ResizeObserver(syncCanvasSize);
    if (imgRef.current) ro.observe(imgRef.current);
    return () => ro.disconnect();
  }, [imgLoaded, syncCanvasSize]);

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || naturalSize.w === 0) return;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const scaleX = canvasSize.w / naturalSize.w;
    const scaleY = canvasSize.h / naturalSize.h;
    let found: number | null = null;
    for (let i = visibleBoxes.length - 1; i >= 0; i--) {
      const { upLeftPoint: ul, downRightPoint: dr } =
        visibleBoxes[i].boundingBox;
      const x = ul.x * scaleX;
      const y = ul.y * scaleY;
      const w = (dr.x - ul.x) * scaleX;
      const h = (dr.y - ul.y) * scaleY;
      if (mx >= x && mx <= x + w && my >= y && my <= y + h) {
        found = i;
        break;
      }
    }
    setHoveredBox(found);
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  // Locate in archive: close overlay and scroll to the card with a highlight arrow
  const handleLocate = () => {
    setLocating(true);
    onClose();
    // Signal to the Home grid via a custom event
    setTimeout(() => {
      window.dispatchEvent(
        new CustomEvent("dms:locate", { detail: { filepath: hit.filepath } }),
      );
    }, 50);
  };

  return (
    <div
      className={styles.backdrop}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className={styles.modal} ref={containerRef}>
        {/* Header */}
        <div className={styles.header}>
          <div className={styles.headerInfo}>
            <span className={styles.filename}>{filename}</span>
            <span className={styles.boxCount}>
              {allBoxes.length} OCR-Blöcke
            </span>
          </div>
          <div className={styles.headerActions}>
            {/* Match-only toggle */}
            {query && (
              <label
                className={styles.matchToggle}
                title="Nur Treffer-Boxen anzeigen"
              >
                <input
                  type="checkbox"
                  checked={matchOnly}
                  onChange={(e) => setMatchOnly(e.target.checked)}
                  style={{ display: "none" }}
                />
                <span
                  className={`${styles.matchToggleBtn} ${matchOnly ? styles.matchToggleBtnOn : ""}`}
                >
                  <svg
                    width="12"
                    height="12"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                  >
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  </svg>
                  Nur Treffer
                </span>
              </label>
            )}

            {/* Locate in archive */}
            <button
              className={styles.locateBtn}
              onClick={handleLocate}
              title="Im Archiv anzeigen"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="3" />
                <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
                <path d="M4.93 4.93l2.12 2.12M16.95 16.95l2.12 2.12M19.07 4.93l-2.12 2.12M7.05 16.95l-2.12 2.12" />
              </svg>
              Im Archiv
            </button>

            <button
              className={styles.closeBtn}
              onClick={onClose}
              aria-label="Schließen"
            >
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>
        </div>

        {/* Image + Canvas */}
        <div className={styles.imageWrap}>
          {hit?.banner_img && !imgError ? (
            <div className={styles.imageContainer}>
              <img
                ref={imgRef}
                src={hit.banner_img}
                alt={filename}
                className={styles.image}
                onLoad={(e) => {
                  const img = e.currentTarget;
                  setNaturalSize({ w: img.naturalWidth, h: img.naturalHeight });
                  setImgLoaded(true);
                  setTimeout(syncCanvasSize, 0);
                }}
                onError={() => setImgError(true)}
                draggable={false}
              />
              <canvas
                ref={canvasRef}
                className={styles.canvas}
                onMouseMove={handleMouseMove}
                onMouseLeave={() => setHoveredBox(null)}
              />
            </div>
          ) : (
            <div className={styles.fallback}>
              <span>Bild nicht verfügbar</span>
            </div>
          )}
          {!imgLoaded && !imgError && (
            <div className={styles.loader}>
              <div className={styles.spinner} />
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className={styles.sidebar}>
          <p className={styles.sidebarTitle}>
            OCR-Text{" "}
            {matchOnly && query && matchBoxes.length > 0 && (
              <span className={styles.sidebarMatchCount}>
                · {matchBoxes.length} Treffer
              </span>
            )}
          </p>
          <div className={styles.lineList}>
            {hit.ocr?.lines?.map((line, li) => (
              <div key={li} className={styles.lineGroup}>
                {line.boxes.map((box, bi) => {
                  const flatIdx =
                    hit.ocr.lines
                      .slice(0, li)
                      .reduce((acc, l) => acc + l.boxes.length, 0) + bi;
                  const visIdx = visibleBoxes.findIndex(
                    (vb) => vb.lineIdx === li && vb.boxIdx === bi,
                  );
                  const isMatch =
                    !!query &&
                    box.text.toLowerCase().includes(query.toLowerCase());
                  if (matchOnly && query && !isMatch) return null;
                  return (
                    <span
                      key={bi}
                      className={`${styles.textChip} ${hoveredBox === visIdx ? styles.textChipActive : ""} ${isMatch ? styles.textChipMatch : ""}`}
                      onMouseEnter={() => visIdx >= 0 && setHoveredBox(visIdx)}
                      onMouseLeave={() => setHoveredBox(null)}
                      title={`Konfidenz: ${(box.confidence * 100).toFixed(1)}%`}
                    >
                      {box.text}
                    </span>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
